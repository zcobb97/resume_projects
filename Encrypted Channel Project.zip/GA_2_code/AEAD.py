"""I/We ____Zach Cobb, Harrison Gentle, and Christopher Kirkman___________ declare that I/We have completed this computer code in accordance with the UAB Academic Integrity Code and the UAB CS Honor Code.  I/We have read the UAB Academic Integrity Code and understand that any breach of the Code may result in severe penalties.	
Student signature(s)/initials: ______zc, hg, ck______	
Date: ___2/23/25_________
"""

import sys

sys.path.insert(0, 'C:/Users/zacha/Documents/Modern_Crypto/pyascon')

from ascon import ascon_encrypt, ascon_decrypt
import os
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305, AESGCM, AESCCM, AESOCB3
#shared_key = os.urandom(16)
shared_nonce = os.urandom(16)
shared_nonce2 = b'0000000000000000'
shared_nonce3 = b'000000000000'
shared_ad = b'CS645/745 Modern Cryptography: Secure Messaging'
def my_encrypt(txt, shared_key):
    #print(shared_key)
    C = 𝑎𝑠𝑐𝑜𝑛_𝑒𝑛𝑐𝑟𝑦𝑝𝑡(shared_key,shared_nonce2, b'CS645/745 Modern Cryptography: Secure Messaging',txt.encode(),𝑣𝑎𝑟𝑖𝑎𝑛𝑡 = "Ascon-128")
    return C

def my_decrypt(txt, shared_key):
    #print(shared_key)
    M = 𝑎𝑠𝑐𝑜𝑛_decrypt(shared_key,shared_nonce2, shared_ad,txt,𝑣𝑎𝑟𝑖𝑎𝑛𝑡 = "Ascon-128")
    return M

def my_cha_cha_encrypt(txt, key):
    my_cha_cha = ChaCha20Poly1305(key)
    my_ct = my_cha_cha.encrypt(shared_nonce3, txt.encode(), shared_ad)
    return my_ct

def my_cha_cha_decrypt(txt, key):
    my_cha_cha = ChaCha20Poly1305(key)
    my_m = my_cha_cha.decrypt(shared_nonce3, txt, shared_ad)
    return my_m

def my_ccm_encrypt(txt, key):
    my_ccm = AESCCM(key)
    my_ct = my_ccm.encrypt(shared_nonce3, txt.encode(), shared_ad)
    return my_ct

def my_ccm_decrypt(txt, key):
    my_ccm = AESCCM(key)
    my_m = my_ccm.decrypt(shared_nonce3, txt, shared_ad)
    return my_m

def my_gcm_encrypt(txt, key):
    my_gcm = AESGCM(key)
    my_ct = my_gcm.encrypt(shared_nonce3, txt.encode(), shared_ad)
    return my_ct

def my_gcm_decrypt(txt, key):
    my_gcm = AESGCM(key)
    my_m = my_gcm.decrypt(shared_nonce3, txt, shared_ad)
    return my_m

def my_ocb3_encrypt(txt, key):
    my_ocb = AESOCB3(key)
    my_ct = my_ocb.encrypt(shared_nonce3, txt.encode(), shared_ad)
    return my_ct

def my_ocb3_decrypt(txt, key):
    my_ocb = AESOCB3(key)
    my_m = my_ocb.decrypt(shared_nonce3, txt, shared_ad)
    return my_m


"""
CT = my_encrypt("hello. my name is Zach.")
print(CT)
My_M = my_decrypt(CT)
print(My_M)"""