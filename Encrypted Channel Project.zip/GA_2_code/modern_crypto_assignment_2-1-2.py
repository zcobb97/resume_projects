"""I/We ____Zach Cobb, Harrison Gentle, and Christopher Kirkman___________ declare that I/We have completed this computer code in accordance with the UAB Academic Integrity Code and the UAB CS Honor Code.  I/We have read the UAB Academic Integrity Code and understand that any breach of the Code may result in severe penalties.	
Student signature(s)/initials: ______zc, hg, ck______	
Date: ___2/23/25_________
"""

# 138.26.210.44


# 172.24.221.48

# 172.24.239.62


# 172.25.93.195

# zs: 172.24.107.135

#cd C:\Users\TC\Desktop\assignment2_crypto 
#python modern_crypto_assignment_2-1.py




import os
import socket
import AEAD
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

def my_KDF(mode, passcode):
    match mode:
        case 1:
            my_key = HKDF(hashes.SHA256(), 16, b"", info=passcode.encode()).derive(passcode.encode())
            return my_key
        case 2:
            my_key = HKDF(hashes.SHA256(), 32, b"", info=passcode.encode()).derive(passcode.encode())
            return my_key
        case 3:
            my_key = HKDF(hashes.SHA256(), 16, b"", info=passcode.encode()).derive(passcode.encode())
            return my_key
        case 4:
            my_key = HKDF(hashes.SHA256(), 16, b"", info=passcode.encode()).derive(passcode.encode())
            return my_key
        case 5:
            my_key = HKDF(hashes.SHA256(), 16, b"", info=passcode.encode()).derive(passcode.encode())
            return my_key

def my_encryption(mode, message, key):
    match mode:
        case 1:
            my_key = AEAD.my_encrypt(message, key)
            return my_key
        case 2:
            my_key = AEAD.my_cha_cha_encrypt(message, key)
            return my_key
        case 3:
            my_key = AEAD.my_ccm_encrypt(message, key)
            return my_key
        case 4:
            my_key = AEAD.my_gcm_encrypt(message, key)
            return my_key
        case 5:
            my_key = AEAD.my_ocb3_encrypt(message, key)
            return my_key

def my_decryption(mode, message, key):
    match mode:
        case 1:
            my_key = AEAD.my_decrypt(message, key)
            return my_key
        case 2:
            my_key = AEAD.my_cha_cha_decrypt(message, key)
            return my_key
        case 3:
            my_key = AEAD.my_ccm_decrypt(message, key)
            return my_key
        case 4:
            my_key = AEAD.my_gcm_decrypt(message, key)
            return my_key
        case 5:
            my_key = AEAD.my_ocb3_decrypt(message, key)
            return my_key

user_a_addr = '127.0.0.1'
user_b_addr = "127.0.0.1"
nonce = 0
associated_data = 'CS645/745 Modern Cryptography: Secure Messaging'
test_key = b'1111111111111111'
test_key2 = b'2222222222222222'

my_user = input("are you user a or user b? \n")

if my_user == 'a':
    user_b_addr = input("Enter user B's IP address: \n")
    my_mode = input("What mode of AEAD are you choosing? \n 1 for ASCON. \n 2 for CHACHA. \n 3 for CCM. \n 4 for GCM. \n  anything else for OCB3. \n")
    my_atob = input("Passcode for key ab? \n")
    my_btoa = input("Passcode for key ba? \n")
    my_mode_type = 0

    try:

        if int(my_mode) == 1:
            my_mode_type = 1
        elif int(my_mode) == 2:
            my_mode_type = 2
        elif int(my_mode) == 3:
            my_mode_type = 3
        elif int(my_mode) == 4:
            my_mode_type = 4
        else:
            print("Defaulted to mode 5 (ocb3) due to your entry not being 1-4")
            my_mode_type = 5

    except ValueError:
        print("Defaulted to mode 5 (ocb3) due to your entry not being 1-4")
        my_mode_type = 5

        

    key_ab = my_KDF(my_mode_type, my_atob)
    key_ba = my_KDF(my_mode_type, my_btoa)
    #print(key_ab)
    #print(key_ba)
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server = (user_b_addr, 7777)
    s.connect(server)
    ender = 0
    while True:
        my_choice = input("Type 1 if you want to send a message. type 2 if you want to end the program. \n")

        try:

            if int(my_choice) == 1:
                my_message = input("type your message \n")
                my_encrypted_message = my_encryption(my_mode_type, my_message, key_ab)
                print("Your message has been encrypted.\n")
                print("Your message in its encrypted cyphertext form:" , my_encrypted_message.hex() + "\n")
                
            #AEAD.my_encrypt(my_message, key_ab)
            #print(my_encrypted_message)
            #print(len(my_encrypted_message))
                s.send(my_encrypted_message)
                
                try:


                    my_response = s.recv(100)

                    print("received encrypted cypher text: \n", my_response.hex())
                    print("unlocking message with using same mode, key, nonce, and associateddata .. \n")


                    decrypted_response = my_decryption(my_mode_type, my_response, key_ba)
            #AEAD.my_decrypt(my_response, key_ba)
                    decoded_response = decrypted_response.decode("UTF-8")
                    print("Transmission received: " + decoded_response + "\n")

                except:
                    print("Other user terminated the session. /n")
                    ender = 1
                    break

            elif int(my_choice) == 2:
                ender = 1
                break

            else:
                print("Enter '1' or '2' please..")

        except ValueError:
            print("Enter '1' or '2' please..")

    s.close()

#________________________________
# (if user b is selected instead or simply just NOT 'a')  
else:
    """my_atob = input("Passcode for key ab? \n")
    my_btoa = input("Passcode for key ba? \n")
    key_ab = HKDF(hashes.SHA256(), 16, b"", info=my_atob.encode()).derive(my_atob.encode())
    key_ba = HKDF(hashes.SHA256(), 16, b"", info=my_btoa.encode()).derive(my_btoa.encode())
    print(key_ab)
    print(len(key_ab))
    print(key_ba)
    print(len(key_ba))"""

    
    user_a_addr = '0.0.0.0'


    my_mode = input("What mode of AEAD are you choosing? \n 1 for ASCON. \n 2 for CHACHA. \n 3 for CCM. \n 4 for GCM. \n  anything else for OCB3. \n")
    my_atob = input("Passcode for key ab? \n")
    my_btoa = input("Passcode for key ba? \n")
    my_mode_type = 0

    try: 
        if int(my_mode) == 1:
            my_mode_type = 1
        elif int(my_mode) == 2:
            my_mode_type = 2
        elif int(my_mode) == 3:
            my_mode_type = 3
        elif int(my_mode) == 4:
            my_mode_type = 4
        else:
            print("Defaulted to mode 5 (ocb3) due to your entry not being 1-4")
            my_mode_type = 5

    except ValueError:
        print("Defaulted to mode 5 (ocb3) due to your entry not being 1-4")
        my_mode_type = 5

    key_ab = my_KDF(my_mode_type, my_atob)
    key_ba = my_KDF(my_mode_type, my_btoa)
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server = (user_a_addr, 7777)
    s.bind(server)
    s.listen(5)
    clientsocket, address = s.accept()
    print("Connection from" + str(address) + "established")
    ender = 0
    while ender < 1:
        my_response = clientsocket.recv(100)

        if not my_response:
            print("Session terminated by the other user . \n")
            break

        print("received encrypted cypher text: \n", my_response.hex())
        print("unlocking message with using same mode, key, nonce, and associateddata .. \n")
    
        #print(my_response)
        #print(len(my_response))
        decrypted_response = my_decryption(my_mode_type, my_response, key_ab)
        #AEAD.my_decrypt(my_response, key_ab)
        decoded_response = decrypted_response.decode("UTF-8")
        
        print("message unlocked (decrypted) successfully.\n")

        print("Transmission received: " + decoded_response + "\n")

        while True:

            my_choice = input("Type 1 if you want to send a message. type 2 if you want to end the program. \n")
            try:

                if int(my_choice) == 1:
                    my_message = input("type your message \n")
                    my_encrypted_message = my_encryption(my_mode_type, my_message, key_ba)
            #AEAD.my_encrypt(my_message, key_ba)
                    print("Your message has been encrypted.\n")
                    print("Your message in its encrypted cyphertext form:" , my_encrypted_message.hex() + "\n")
                    clientsocket.send(my_encrypted_message)
                    break

                elif int(my_choice) == 2:
                    ender = 1
                    break

                else:
                    print("Please enter either '1' or '2' ..")

            except ValueError:
                print("Please enter either '1' or '2'.. ")

    clientsocket.close()


                
        
    