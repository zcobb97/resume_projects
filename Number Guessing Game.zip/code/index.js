async function my_set_bet_amount(bet){
    console.log(bet)
    return await set_bet_amount(parseInt(bet))
}

async function my_guess_check(guess){
    return await guess_check(guess)
}

async function my_get_guess_count(){
    return await get_guess_count()
}

async function my_get_h_or_l(){
    return await get_h_or_l()
}

async function start()
{
 myaddress =  await get_my_address()
 console.log(myaddress);
 //var msg =await getMessage();
 //updateMessage(msg)
//var bal= await getMyBalance()
//updateBalance(bal)

 //   await setMessage();
 mygc =  await get_guess_count()
 console.log(mygc);

 mybet =  await get_bet_amount()
 console.log(mybet);

}

function hideDiv1(){
    var my_div = document.getElementById("address_div")
    my_div.style.display = "none"
    var my_div2 = document.getElementById("bet_div")
    my_div2.style.display = "block"
}
function hideDiv2(){
    var my_div = document.getElementById("bet_div")
    my_div.style.display = "none"
     var my_div2 = document.getElementById("guess_div")
    my_div2.style.display = "block"
    var my_bet = document.getElementById("user_bet")
    set_my_bet = my_set_bet_amount(my_bet.value)
}
function hideDiv3(){
    var my_div = document.getElementById("guess_div")
    my_div.style.display = "none"
}
function minusOneGuess(){
   // myspan = document.getElementById("guess_number_span")
    //mynumber = myspan.innerText
    myguess = document.getElementById("user_guess")
    result_of_guess = my_guess_check(myguess.value)
    console.log(result_of_guess)
    //mynumber =  my_get_guess_count() 
    //console.log(mynumber)
    //myspan.innerText = mynumber
    //myhorl = my_get_h_or_l()
    //console.log(myhorl)
    //myspan2 = document.getElementById("guess_number_span")
    //myspan2.innerText = myhorl
     
}


 start();