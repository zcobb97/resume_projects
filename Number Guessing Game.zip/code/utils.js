// How contract talks to index.

const mycontractAddress = "0xfa3DF4405a3d42501a4f010cAEF9D1C61C22fAdC";

const mycontractABI = [
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_guess",
				"type": "uint256"
			}
		],
		"name": "check_guess",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "deposit",
		"outputs": [],
		"stateMutability": "payable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "end_contract",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "randMod",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "set_bet_amount",
		"outputs": [],
		"stateMutability": "payable",
		"type": "function"
	},
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"inputs": [],
		"name": "get_bet_amount",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "get_guess_count",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "get_h_or_l",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "get_my_address",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "get_rand_number",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
]

var myweb3;

async function  connect()
{
 
    accounts = await window.ethereum.request({method:"eth_requestAccounts"})
    account = accounts[0]
    window.web3 = new Web3(window.ethereum);
    myweb3= window.web3
}

async function get_rand_number() {
    
}

async function get_guess_count() {
    accounts = await window.ethereum.request({method:"eth_requestAccounts"})
    account = accounts[0]
    window.web3 = new Web3(window.ethereum);
    myweb3= window.web3
    

   myconractInstance = new web3.eth.Contract(mycontractABI,mycontractAddress)
   var myresult=await myconractInstance.methods.get_guess_count().call({"from":account})

   console.log(myresult)
   myspan = document.getElementById("guess_number_span")
   myspan.innerText = myresult
   //return myresult
}
async function get_bet_amount() {
	accounts = await window.ethereum.request({method:"eth_requestAccounts"})
    account = accounts[0]
    window.web3 = new Web3(window.ethereum);
    myweb3= window.web3
    

   myconractInstance = new web3.eth.Contract(mycontractABI,mycontractAddress)
   var myresult=await myconractInstance.methods.get_bet_amount().call({"from":account})

   console.log(myresult)
   return myresult
    
}
async function get_my_address() {
    accounts = await window.ethereum.request({method:"eth_requestAccounts"})
   account = accounts[0]
   return account;
}

async function set_bet_amount(msg) {
	accounts = await window.ethereum.request({method:"eth_requestAccounts"})
    account = accounts[0]
    window.web3 = new Web3(window.ethereum);
    myweb3= window.web3
    console.log(msg)
   myconractInstance = new web3.eth.Contract(mycontractABI,mycontractAddress)
   var msg_ether = msg * 1000000000000000000
   var myresult=await myconractInstance.methods.set_bet_amount().send({"from":account, value:msg_ether})
   console.log(myresult)
   myresult=await myconractInstance.methods.get_guess_count().call({"from":account})
   myspan = document.getElementById("guess_number_span")
   myspan.innerText = myresult  
    
}

async function guess_check(msg) {
    accounts = await window.ethereum.request({method:"eth_requestAccounts"})
    account = accounts[0]
    window.web3 = new Web3(window.ethereum);
    myweb3= window.web3
    

   myconractInstance = new web3.eth.Contract(mycontractABI,mycontractAddress)
   var myresult=await myconractInstance.methods.check_guess(msg).send({"from":account})

   console.log(myresult)
   myresult=await myconractInstance.methods.get_guess_count().call({"from":account})

   console.log(myresult)
   myspan = document.getElementById("guess_number_span")
   myspan.innerText = myresult

   myresult=await myconractInstance.methods.get_h_or_l().call({"from":account})

   console.log(myresult)
   myspan2 = document.getElementById("h_or_l_span")
   myspan2.innerText = myresult
   var myresult2=await myconractInstance.methods.get_rand_number().call({"from":account})

   if(myspan.innerText == 0){
	var my_div = document.getElementById("guess_div")
    my_div.style.display = "none"
	var my_div = document.getElementById("Lose_div")
    my_div.style.display = "block"
	var myspan = document.getElementById("loss_span")
	myspan.innerText = await myconractInstance.methods.get_bet_amount().call({"from":account})/ 1000000000000000000
   }
   else if(msg == myresult2){
	var my_div = document.getElementById("guess_div")
    my_div.style.display = "none"
	var my_div = document.getElementById("win_div")
    my_div.style.display = "block"
	var myspan = document.getElementById("prize_span")
	myspan.innerText = (await myconractInstance.methods.get_bet_amount().call({"from":account}) * 2)/ 1000000000000000000
   }

   return myresult
}

async function get_h_or_l() {
	accounts = await window.ethereum.request({method:"eth_requestAccounts"})
    account = accounts[0]
    window.web3 = new Web3(window.ethereum);
    myweb3= window.web3
    

   myconractInstance = new web3.eth.Contract(mycontractABI,mycontractAddress)
   var myresult=await myconractInstance.methods.get_h_or_l().call({"from":account})

   console.log(myresult)
   myspan2 = document.getElementById("h_or_l_span")
   myspan2.innerText = myresult
   //return myresult
    
}
