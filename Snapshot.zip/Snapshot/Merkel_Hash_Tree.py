import os
from cryptography.hazmat.primitives import hashes



def pruning(digest_list):
    if len(digest_list) == 1:
        return digest_list[0]
    else:
        new_list = []
        for i in range(0, len(digest_list), 2):
            digest = hashes.Hash(hashes.SHA256())
            if (i+1) >= len(digest_list):
                digest.update(digest_list[i])
                digest.update(digest_list[i])
                new_list.append(digest.finalize())
            else:
                digest.update(digest_list[i])
                digest.update(digest_list[i+1])
                new_list.append(digest.finalize())
        return pruning(new_list)

def hash_tree(path):
    current_dir = os.listdir(path)
    #print(current_dir)
    List_of_digests = []
    for f in current_dir:
        print(f)
        digest = hashes.Hash(hashes.SHA256())
        if os.path.isdir(f):
            print(path + "/" + f)
            sub_hashroot = hash_tree(path + "/" + f)
            List_of_digests.append(sub_hashroot)
        my_file = open(path + "/"+ f, "rb")
        my_file_data = my_file.read()
        my_file.close()
        digest.update(my_file_data)
        List_of_digests.append(digest.finalize())
    print(List_of_digests)
    return pruning(List_of_digests)

current_dir = os.listdir(".")
#print(current_dir)
List_of_digests = []
for f in current_dir:
    digest = hashes.Hash(hashes.SHA256())
    if os.path.isdir(f):
        sub_hashroot = hash_tree("." + "/" + f)
        List_of_digests.append(sub_hashroot)
    my_file = open(f, "rb")
    my_file_data = my_file.read()
    my_file.close()
    digest.update(my_file_data)
    List_of_digests.append(digest.finalize())
print(List_of_digests)
mhr = pruning(List_of_digests)
print(mhr)