import os
from cryptography.hazmat.primitives import hashes
from quantcrypt.dss import FAST_SPHINCS
import time
import struct


print("IF THIS IS YOUR FIRST RUN:")
print("PLEASE DELETE 'hash_folder' IF YOU HAVE NOT ALREADY")
print(" ")

def pruning(digest_list):
    if len(digest_list) == 1:
        return digest_list[0]
    else:
        new_list = []
        for i in range(0, len(digest_list), 2):
            digest = hashes.Hash(hashes.SHA256())
            if (i+1) >= len(digest_list):
                digest.update(digest_list[i])
                digest.update(digest_list[i])
                new_list.append(digest.finalize())
            else:
                digest.update(digest_list[i])
                digest.update(digest_list[i+1])
                new_list.append(digest.finalize())
        return pruning(new_list)

def hash_tree(path):
    current_dir = os.listdir(path)
    #print(current_dir)
    List_of_digests = []
    for f in current_dir:
        #print(f)
        digest = hashes.Hash(hashes.SHA256())
        if os.path.isdir(path + "/" +f):
            #print(path + "/" + f)
            if len(os.listdir(path + "/" +f)) == 0:
                continue
            sub_hashroot = hash_tree(path + "/" + f)
            print(path + "/" + f + " hashroot: \n")
            print(sub_hashroot)
            print("")
            if os.path.exists(path + "/"  + f + "_hashroot.txt") == True:
                my_f = open(path + "/"  + f + "_hashroot.txt", 'r')
                past_subroot = my_f.read()
                if str(sub_hashroot) != past_subroot:
                    my_f = open(path + "/"  + f + "_hashroot.txt", 'w')
                    my_f.write(str(sub_hashroot))
                    my_f.close()
                    List_of_digests.append(sub_hashroot)
                    continue
                else:
                    List_of_digests.append(sub_hashroot)
                    continue

            my_f = open(path + "/"  + f + "_hashroot.txt", 'w')
            my_f.write(str(sub_hashroot))
            my_f.close()
            List_of_digests.append(sub_hashroot)
            new_digest = hashes.Hash(hashes.SHA256())
            my_f = open(path + "/"  + f + "_hashroot.txt", 'rb')
            my_new_data = my_f.read()
            my_f.close()
            new_digest.update(my_new_data)
            List_of_digests.append(new_digest.finalize())
            continue
        my_file = open(path + "/"+ f, "rb")
        my_file_data = my_file.read()
        my_file.close()
        digest.update(my_file_data)
        List_of_digests.append(digest.finalize())
    #print(List_of_digests)
    return pruning(List_of_digests)

#the_constant = b"00000000"

# explicitly 256 bits worth of 0s
the_constant = bytes(32)

ender = 0
counter = 1

"""if os.path.exists('../hash_folder/current_chain.txt') == True:
    the_file = open('../hash_folder/current_chain.txt', 'r')
    my_info = the_file.readline()
    counter = int(my_info[0])
    the_constant = my_info[1]
    the_file.close()"""
my_interval = input("Enter in the minutes for each interval\n ex: enter 5 for 5 minute intervals between snapshots.\n")
number_of_days = input("How many rounds / days should this be run ?")

try:
    my_interval = int(my_interval)
    number_of_days = int(number_of_days)
    print("Building hash chain on the basis of your inputted time.. \n")

except ValueError:
    
    print("input not accepted - Please enter an int..")
    print(" ")
    exit(1)
    





if os.path.exists('../hash_folder') == False:
    os.mkdir('../hash_folder')

f = open("H0.txt", "w")
f.write(str(the_constant) + '\n')
f.write(str(time.time()) + '\n')
f.write("initial hash of 0s so no signature")
f.close()

os.rename(os.getcwd() + '/H0.txt', '../hash_folder/H0.txt')


iterCount = 1

while iterCount <= number_of_days:
        my_hash_tree = hash_tree(".")
        digest = hashes.Hash(hashes.SHA256())
        digest.update(the_constant)
        digest.update(my_hash_tree)
        my_hash_of_the_day = digest.finalize()
        print("here's the hash of the system.")
        print(my_hash_tree)
        print(" ")
        print("Here's the hash of the previous day")
        print(the_constant)
        print(" ")
        print("Here's the hash of the day")
        print(my_hash_of_the_day)
        print(" ")
        the_constant = my_hash_of_the_day
        dss = FAST_SPHINCS()
        public_key, secret_key = dss.keygen()
        my_time = time.time()
        my_time_int = int(my_time)
        my_time_bytes = struct.pack('>i', my_time_int)
        my_message = my_hash_of_the_day + my_time_bytes
        signature = dss.sign(secret_key, my_message)
        print("it's signature is in file.")
        #print(signature)
    
        f = open("H" + str(counter) + ".txt", "w")
        #f.write(str(my_hash_of_the_day) + '\n')
        f.write(str(my_time) + '\n')
        f.write(str(signature))
        f.close()

        if os.path.exists('../hash_folder') == True:
            os.rename(os.getcwd()  + '/'+ 'H' + str(counter) +".txt", '../hash_folder/'+  'H' + str(counter) +".txt")
        else:
            os.mkdir('../hash_folder')
            os.rename(os.getcwd()  + '/'+  'H' + str(counter) +".txt", '../hash_folder/'+  'H' + str(counter) +".txt")
        counter += 1

        # doing check for usr input quit status
        print("(Hash" , (counter-1) , "done (1 day has elapsed.)")
        print(" ")

        if iterCount < number_of_days:
            print("Waiting", (my_interval), "minutes ('days') for next snapshot..")
            time.sleep(int(my_interval) * 60)

        iterCount += 1
print("All days elapsed. Exiting Program.. \n")
print(" ")
print("Exited program.")